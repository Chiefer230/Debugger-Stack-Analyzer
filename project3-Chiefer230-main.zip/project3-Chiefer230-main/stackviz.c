#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "StackNode.h"
int NodeNumber = 1;                     // Counter for the Amount of Nodes within the List
struct FunctionNode *temp = NULL;       // Used to create the list
struct FunctionNode *Head = NULL;       // Used to Hold the List
struct FunctionNode *SortedList = NULL; // Node used to sort
/**
 * This Method is used sort the function by its end time
 */
void sortedEnd(struct FunctionNode *Temp)
{
  if (SortedList == NULL)
  {
    Temp->Next = SortedList;
    SortedList = Temp;
  }
  else
  {
    struct FunctionNode *current = SortedList;
    while (current->Next != NULL && current->Next->EndTime.tv_sec == Temp->EndTime.tv_sec && current->Next->EndTime.tv_nsec > Temp->EndTime.tv_nsec)
    {
      current = current->Next;
    }
    Temp->Next = current->Next;
    current->Next = Temp;
  }
}
/*
* This Function Sorts the PID and associtates with start time for each Node
*/
void sortedPID(struct FunctionNode *Temp)
{
  if (SortedList == NULL)
  {
    Temp->Next = SortedList;
    SortedList = Temp;
  }
  else
  {
    struct FunctionNode *current = SortedList;
    while (current->Next != NULL && current->Next->ProcessIDStart > Temp->ProcessIDStart && current->Next->startTime.tv_sec == Temp->startTime.tv_sec && current->Next->startTime.tv_nsec > Temp->startTime.tv_nsec)
    {
      current = current->Next;
    }
    Temp->Next = current->Next;
    current->Next = Temp;
  }
}
/**
 * Sorts the list based on the Start Time of the Function Nodes
 */
void sortedStart(struct FunctionNode *Temp)
{
  if (SortedList == NULL)
  {
    Temp->Next = SortedList;
    SortedList = Temp;
  }
  else
  {
    struct FunctionNode *current = SortedList;
    while (current->Next != NULL && current->Next->startTime.tv_sec == Temp->startTime.tv_sec && current->Next->startTime.tv_nsec > Temp->startTime.tv_nsec)
    {
      current = current->Next;
    }
    Temp->Next = current->Next;
    current->Next = Temp;
  }
}
/**
 * Menu Function to deciede how to sort the Linked list based on the flag inputted by the user
 * The List is SortedList by using Insertion Sort over a while loop
 */
void insertionsort(struct FunctionNode *Head, char *sort)
{

  struct FunctionNode *current = Head;

  while (current != NULL)
  {

    struct FunctionNode *Next = current->Next;
    if (strcmp(sort, "-s"))
    {
      sortedStart(current);
    }
    else if (strcmp(sort, "-f"))
    {
      sortedEnd(current);
    }
    else if (strcmp(sort, "-p"))
    {
      sortedPID(current);
    }
    // insert current in SortedList linked list
    // Update current
    current = Next;
  }
  // Update head to point to SortedList linked list
  Head = SortedList;
}
/*
This Method prints all the information for each Node within the list
All Attributes from the ProcessID,Parent ProcessID, Function addresses, call site address, the time for the Node, and the Node Number
*/
void printFunctionNode(struct FunctionNode *CurrentNode)
{
  printf("===============================================\n");
  printf("\nNode Number (%i)", NodeNumber);
  printf("\nStart Process: %d, Start Parent Process: %d,", CurrentNode->ProcessIDStart, CurrentNode->ParentProcessIDStart);
  printf("\nEnd Process: %d, End Parent Process: %d,", CurrentNode->ProcessIDEnd, CurrentNode->ParentProcessIDEnd);
  printf("\nFunction: %p, Caller: %p, Frame pointer: %p\n", CurrentNode->FunctionAddress, CurrentNode->CallSite, CurrentNode->FramePointer);
  printf("Stack Frame: %p-%p,(%ld.%09ld-%ld.%09ld)\n", CurrentNode->BegAddress, CurrentNode->EndAddress, CurrentNode->startTime.tv_sec, CurrentNode->startTime.tv_nsec, CurrentNode->EndTime.tv_sec, CurrentNode->EndTime.tv_nsec);
  // Distance between the Begin and End address which is the Offset of the frame
  int distance = (CurrentNode->BegAddress - CurrentNode->EndAddress);
  int Offest = distance;
  printf("OFFSET:%d\n", Offest);
  printf("address range                  initial  | final\n");
  printf("===============================================\n");
  // Using the Offset and dividing it by 4 because we need to output 4 bytes each line, Each iteration decements until the end address is hit
  for (int i = (distance - 1) / 4; i >= 0; i--)
  {
    // pointer for the Start Address Value
    int *begin = (int *)(CurrentNode->EndAddress);
    // This is used to check if the distance in each line is correct at 4 bytes
    void *Rangedistance = ((int)(CurrentNode->EndAddress + i) + 4) - (int)(CurrentNode->EndAddress + i);
    printf("\nRange Distance:%d\n", Rangedistance);
    // Assigns the begin and end pointers to output address range where the begin address will be 3 bytes ahead of the End address depsite the index
    unsigned char *Beg = (char *)(begin + i) + 3;
    unsigned char *End = (char *)(begin + i);
    // Prints the Begin/End pointers, The dereferenced inital and final contents after each iteration or line of 4 bytes
    printf("%p-%p: %08x | %08x\n", Beg, End, *(CurrentNode->initial_contents + i), *(CurrentNode->final_contents + i));
  }
}
/**
 * Method Used to print the list of Nodes from the list despite being SortedList or unsorted
 */
void printList(struct FunctionNode *H)
{
  while (H != NULL)
  {

    printFunctionNode(H);
    H = H->Next;
    NodeNumber++;
  }
}

int main(int argc, char *argv[])
{
  // File Options to check if the file exists
  int fp = open(argv[1], O_RDONLY);
  // Checks for correct amount of arguements
  if (argc != 3)
  {
    perror("Wrong amount of arg");
  }
  if (fp == -1)
  {
    fprintf(stderr, "File Not Reachable\n");
    return 1;
  }

  // Traversing the list and reading each of the information until it fails
  // The contents are allocated in order to retrieve and output correctly
  // Reads the last two lines to grab the contents from the binary file
  // Recreates the Linked List to be used to sort depending on the user's Flag input
  while (1)
  {
    FunctionNode *CurrentNode = (FunctionNode *)malloc(sizeof(FunctionNode));
    if (read(fp, CurrentNode, sizeof(FunctionNode)) == 0)
    {
      break;
    }
    // Allocates for the contents and uses the distance between the begin and end addresses to implement the size
    size_t size = CurrentNode->BegAddress - CurrentNode->EndAddress;
    CurrentNode->initial_contents = malloc(size);
    CurrentNode->final_contents = malloc(size);
    // Reads the last two lines of each FunctionNode in the Binary File specifically catered to the contents
    read(fp, CurrentNode->initial_contents, size);
    read(fp, CurrentNode->final_contents, size);
    // Create the Linked List
    CurrentNode->Next = Head;
    Head = CurrentNode;
  }
  // Sorts the List based on the Times given
  insertionsort(Head, argv[2]);
  // Print the Function's Information recorded in inst.c from the Binary File
  printList(Head);
  close(fp);
  return 0;
}
