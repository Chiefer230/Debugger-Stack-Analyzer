/*
 This struct is used to hold the Functions Stack Frame Inofrmation in an organized fashion
 The information is stored in inst.c where the enter/exit functions produce the information
 From there, the struct's information is then accessed and outputted in stackviz.c
*/
typedef struct FunctionNode
{
  struct timespec startTime, EndTime; // Start and End times of the processes
  int NodeNumber;                     // Node Number Used to keep track of which index it is in the linked list
  pid_t ProcessIDStart;               // ProcessID which is recorded from the beginning of the Enter Function
  pid_t ParentProcessIDStart;         // ParentProcessID which is recorded from the beginning of the Enter Function
  pid_t ProcessIDEnd;                 // ProcessID which is recorded from the beginning of th Exit Function
  pid_t ParentProcessIDEnd;           // ParentProcessID which is recorded from the beginning of the Exit Function
  void *FunctionAddress;              // Function Address used to Store this_fn from the Enter/Exit
  void *CallSite;                     // Function Call site is stored in here
  int *FramePointer;                  // pointer used to Store the Function's Frame Pointer
  void *BegAddress;                   // Pointer used to store the Function's Beginning Address
  void *EndAddress;                   // Pointer used to store the Function's End Address
  unsigned int *initial_contents;     // Unsigned int Pointer (4 bytes) to hold the initial contents at Function Entry
  unsigned int *final_contents;       // Unsigned int Pointer (4 bytes) to hold the Final contents at Function Exit
  struct FunctionNode *Next;          // Node Pointer used to traverse and construct the linked list of stack frames
} FunctionNode;