#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "StackNode.h"
pthread_mutex_t lock_x;        // Mutex that Handles the race condition
struct timespec start, end;    // Used to Record the Time of the Operations
FunctionNode *head = NULL;     // Head of the Linked List
FunctionNode *Function = NULL; // The Function that is updated throughout the implementation
int fp;                        // File used to store the contents

/*
 GCC inlcuded default method used to open the file at the first Enter function of the program
This will execute As soon as the program begins thus opening the file in it's first Enter function
*/
void __attribute__((constructor)) openfile();

void openfile()
{
  fp = open("stack.bin", O_WRONLY | O_CREAT | O_TRUNC);
  if (fp == -1)
  {
    perror("File Will Not Open");
  }
}

/*
Enter Function used to grab initial values of Function Address, CallSite, FramePointer,Beginning Addresses, Ending Addresses and the Start Time
Another functionality of this function is to create a chain of Functions based on the execution of Enter/Exit functions
In Test.c Enter is called 4 times back to back which makes it harder to keep track of which function entered and exits.
*/
void __cyg_profile_func_enter(void *this_fn, void *call_site)
{

  // Initial Information that can be applied to a Function Node at the Entry of a Function

  Function = (FunctionNode *)malloc(sizeof(FunctionNode));
  // Record the ProcessID and the ParentProcess ID in the Enter Function
  Function->ProcessIDStart = getpid();
  Function->ParentProcessIDStart = getppid();
  Function->FunctionAddress = this_fn;
  Function->CallSite = call_site;
  Function->FramePointer = __builtin_frame_address(1);
  Function->BegAddress = __builtin_frame_address(1) + 2 * sizeof(void *);
  Function->EndAddress = __builtin_frame_address(0) + 4 * sizeof(void *);
  int size = (Function->BegAddress - Function->EndAddress);
  // Allocating Memory based on the distance between the Beginning Address and the End Address for the contents after and before execution
  // The memory is then copied to the inital contents because it will be used as a reference to see if contents change after exit
  Function->initial_contents = malloc(size);
  Function->final_contents = malloc(size);
  memcpy(Function->initial_contents, Function->EndAddress, size);
  // Record the Start Time of the Function at Enter and divide it by the Clocks per Speed for a float value
  clock_gettime(CLOCK_MONOTONIC, &Function->startTime);
  // Linked List Implementation used to chain the Functions together at enter
  Function->Next = head;
  head = Function;
}
/*
The exit function is used to grab the Final contents, End Time and the Total RunTime
Inorder to update the information correctly, each function's distinct function address and call site must matcht the Exit's parameters
*/
void __cyg_profile_func_exit(void *this_fn, void *call_site)
{

  // Need to traverse the List in order to find which specific functions to update
  // This is required due to the execution of the Enter and Exit Functions' order
  FunctionNode *CurrentFrameNode = head;
  while (CurrentFrameNode != NULL)
  {

    // Need to check if the CurrentFrameNode Node's Function Address and CallSite Address are the same
    if ((CurrentFrameNode->FunctionAddress == this_fn && CurrentFrameNode->CallSite == call_site) && CurrentFrameNode->FramePointer == __builtin_frame_address(1))
    {
      CurrentFrameNode->ProcessIDEnd = getpid();
      CurrentFrameNode->ParentProcessIDEnd = getppid();
      // The memory for final contents are copied to use a refernce to compare the previous initial contents to see which frame's changed
      size_t size = (size_t)(CurrentFrameNode->BegAddress - CurrentFrameNode->EndAddress);
      memcpy(CurrentFrameNode->final_contents, CurrentFrameNode->EndAddress, size);
      // Record the End Time of the Function at exit and calculate the total Running Time by subtracting the EndTime by the Start Time
      clock_gettime(CLOCK_MONOTONIC, &CurrentFrameNode->EndTime);
      // synchronize the Write of the Nodes to prevent the Race Condition
      pthread_mutex_lock(&lock_x);
      write(fp, CurrentFrameNode, sizeof(FunctionNode));
      write(fp, CurrentFrameNode->initial_contents, CurrentFrameNode->BegAddress - CurrentFrameNode->EndAddress);
      write(fp, CurrentFrameNode->final_contents, CurrentFrameNode->BegAddress - CurrentFrameNode->EndAddress);
      pthread_mutex_unlock(&lock_x);
      // Write the FunctionNode to a binary file to store the data for each function
      // Inorder to access the contents of each function in stackviz.c without interfering with the rest of the contents, the contents are written after to simply retrieving information
      break;
    }
    // Proceed to the Next Node in the list until Next is Null
    CurrentFrameNode = CurrentFrameNode->Next;
  }
}

/*
 GCC default Attribute method used to close the file at the last Exit function of the program
This will automatically execute in the last exit Function
*/
void __attribute__((destructor)) closefile();
void closefile()
{
  close(fp);
  if (fp == -1)
  {
    perror("File Will Not Close");
  }
}